package com.study.springboot.bean;

import org.springframework.stereotype.controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
// Bean으로 등록; 스프링이 원할 때 가져다 쓸 수 있게 한다

public class MyController {
	
	@RequestMapping("/")
	// 브라우저에 입력하는 주소
	// 주소가 맞는 메소드를 실행
	public @ResponseBody String root() {
	
	
	}
}